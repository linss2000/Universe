(function (global, factory) {
	typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('react'), require('prop-types')) :
	typeof define === 'function' && define.amd ? define(['exports', 'react', 'prop-types'], factory) :
	(factory((global.ReactFormWithConstraints = {}),global.React,global.PropTypes));
}(this, (function (exports,React,PropTypes) { 'use strict';

/*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
/* global Reflect, Promise */

var extendStatics = Object.setPrototypeOf ||
    ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
    function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };

function __extends(d, b) {
    extendStatics(d, b);
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}

var __assign = Object.assign || function __assign(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
};

function __rest(s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
}















function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    }
    catch (error) { e = { error: error }; }
    finally {
        try {
            if (r && !r.done && (m = i["return"])) m.call(i);
        }
        finally { if (e) throw e.error; }
    }
    return ar;
}

function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++)
        ar = ar.concat(__read(arguments[i]));
    return ar;
}

var EventEmitter = (function () {
    function EventEmitter() {
        this.listeners = new Map();
    }
    EventEmitter.prototype.emit = function (eventName) {
        var args = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            args[_i - 1] = arguments[_i];
        }
        var listeners = this.listeners.get(eventName);
        if (listeners !== undefined) {
            console.assert(listeners.length > 0, "No listener for event '" + eventName + "'");
            listeners.forEach(function (listener) { return listener.apply(void 0, __spread(args)); });
        }
    };
    EventEmitter.prototype.addListener = function (eventName, listener) {
        if (!this.listeners.has(eventName))
            this.listeners.set(eventName, []);
        var listeners = this.listeners.get(eventName);
        console.assert(listeners.indexOf(listener) === -1, "Listener already added for event '" + eventName + "'");
        listeners.push(listener);
    };
    EventEmitter.prototype.removeListener = function (eventName, listener) {
        var listeners = this.listeners.get(eventName);
        console.assert(listeners !== undefined, "Unknown event '" + eventName + "'");
        var index = listeners.lastIndexOf(listener);
        console.assert(index > -1, "Listener not found for event '" + eventName + "'");
        listeners.splice(index, 1);
        if (listeners.length === 0)
            this.listeners.delete(eventName);
    };
    return EventEmitter;
}());

var ValidateEvent = 'VALIDATE_EVENT';
function withValidateEventEmitter(Base) {
    return (function (_super) {
        __extends(ValidateEventEmitter, _super);
        function ValidateEventEmitter() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.validateEventEmitter = new EventEmitter();
            return _this;
        }
        ValidateEventEmitter.prototype.emitValidateEvent = function (input) {
            this.validateEventEmitter.emit(ValidateEvent, input);
        };
        ValidateEventEmitter.prototype.addValidateEventListener = function (listener) {
            this.validateEventEmitter.addListener(ValidateEvent, listener);
        };
        ValidateEventEmitter.prototype.removeValidateEventListener = function (listener) {
            this.validateEventEmitter.removeListener(ValidateEvent, listener);
        };
        return ValidateEventEmitter;
    }(Base));
}

var fieldWithoutFeedback = {
    dirty: false,
    errors: new Set(),
    warnings: new Set(),
    infos: new Set(),
    validationMessage: ''
};

(function (FieldEvent) {
    FieldEvent["Added"] = "FIELD_ADDED";
    FieldEvent["Removed"] = "FIELD_REMOVED";
    FieldEvent["Updated"] = "FIELD_UPDATED";
})(exports.FieldEvent || (exports.FieldEvent = {}));
var FieldsStore = (function (_super) {
    __extends(FieldsStore, _super);
    function FieldsStore() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.fields = Object.create(null);
        return _this;
    }
    FieldsStore.prototype.addField = function (fieldName) {
        if (this.fields[fieldName] === undefined) {
            var newField = fieldWithoutFeedback;
            this.fields[fieldName] = newField;
            this.emit(exports.FieldEvent.Added, fieldName, newField);
        }
    };
    FieldsStore.prototype.removeField = function (fieldName) {
        console.assert(this.fields[fieldName] !== undefined, "Unknown field '" + fieldName + "'");
        delete this.fields[fieldName];
        this.emit(exports.FieldEvent.Removed, fieldName);
    };
    FieldsStore.prototype.cloneField = function (fieldName) {
        var field = this.fields[fieldName];
        console.assert(field !== undefined, "Unknown field '" + fieldName + "'");
        var newField = {
            dirty: field.dirty,
            errors: new Set(field.errors),
            warnings: new Set(field.warnings),
            infos: new Set(field.infos),
            validationMessage: field.validationMessage
        };
        return newField;
    };
    FieldsStore.prototype.updateField = function (fieldName, field) {
        console.assert(this.fields[fieldName] !== undefined, "Unknown field '" + fieldName + "'");
        this.fields[fieldName] = field;
        this.emit(exports.FieldEvent.Updated, fieldName);
    };
    FieldsStore.prototype.removeFieldFor = function (fieldName, fieldFeedbacksKey) {
        var field = this.fields[fieldName];
        console.assert(field !== undefined, "Unknown field '" + fieldName + "'");
        var reject = function (fieldFeedbackKey) { return fieldFeedbacksKey !== Math.floor(fieldFeedbackKey); };
        field.errors = new Set(Array.from(field.errors).filter(reject));
        field.warnings = new Set(Array.from(field.warnings).filter(reject));
        field.infos = new Set(Array.from(field.infos).filter(reject));
        this.emit(exports.FieldEvent.Updated, fieldName);
    };
    FieldsStore.prototype.getFieldFor = function (fieldName, fieldFeedbacksKey) {
        var field = this.fields[fieldName];
        console.assert(field !== undefined, "Unknown field '" + fieldName + "'");
        var filter = function (fieldFeedbackKey) { return fieldFeedbacksKey === Math.floor(fieldFeedbackKey); };
        var fieldFor = {
            dirty: field.dirty,
            errors: new Set(Array.from(field.errors).filter(filter)),
            warnings: new Set(Array.from(field.warnings).filter(filter)),
            infos: new Set(Array.from(field.infos).filter(filter)),
            validationMessage: field.validationMessage
        };
        return fieldFor;
    };
    FieldsStore.prototype.containErrors = function () {
        var _this = this;
        var fieldNames = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fieldNames[_i] = arguments[_i];
        }
        return fieldNames.some(function (fieldName) {
            var field = _this.fields[fieldName];
            return field !== undefined && field.errors.size > 0;
        });
    };
    FieldsStore.prototype.containWarnings = function () {
        var _this = this;
        var fieldNames = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fieldNames[_i] = arguments[_i];
        }
        return fieldNames.some(function (fieldName) {
            var field = _this.fields[fieldName];
            return field !== undefined && field.warnings.size > 0;
        });
    };
    FieldsStore.prototype.containInfos = function () {
        var _this = this;
        var fieldNames = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fieldNames[_i] = arguments[_i];
        }
        return fieldNames.some(function (fieldName) {
            var field = _this.fields[fieldName];
            return field !== undefined && field.infos.size > 0;
        });
    };
    FieldsStore.prototype.areValidDirtyWithoutWarnings = function () {
        var _this = this;
        var fieldNames = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            fieldNames[_i] = arguments[_i];
        }
        return fieldNames.some(function (fieldName) {
            var field = _this.fields[fieldName];
            return field !== undefined && field.dirty === true && field.errors.size === 0 && field.warnings.size === 0;
        });
    };
    return FieldsStore;
}(EventEmitter));

var FormWithConstraintsComponent = (function (_super) {
    __extends(FormWithConstraintsComponent, _super);
    function FormWithConstraintsComponent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FormWithConstraintsComponent;
}(React.Component));
var FormWithConstraints = (function (_super) {
    __extends(FormWithConstraints, _super);
    function FormWithConstraints() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.fieldsStore = new FieldsStore();
        _this.fieldFeedbacksKey = 0;
        return _this;
    }
    FormWithConstraints.prototype.getChildContext = function () {
        return {
            form: this
        };
    };
    FormWithConstraints.prototype.computeFieldFeedbacksKey = function () {
        return this.fieldFeedbacksKey++;
    };
    FormWithConstraints.prototype.validateFields = function () {
        var _this = this;
        var inputsOrNames = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            inputsOrNames[_i] = arguments[_i];
        }
        var inputs = inputsOrNames.filter(function (inputOrName) { return typeof inputOrName !== 'string'; });
        var fieldNames = inputsOrNames.filter(function (inputOrName) { return typeof inputOrName === 'string'; });
        var otherInputs = [];
        if (inputsOrNames.length === 0) {
            otherInputs = this.form.querySelectorAll('[name]');
        }
        if (fieldNames.length > 0) {
            var selectors = fieldNames.map(function (fieldName) { return "[name=\"" + fieldName + "\"]"; });
            otherInputs = this.form.querySelectorAll(selectors.join(', '));
        }
        __spread(inputs, otherInputs).forEach(function (input) { return _this.emitValidateEvent(input); });
    };
    FormWithConstraints.prototype.isValid = function () {
        var fieldNames = Object.keys(this.fieldsStore.fields);
        return !(_a = this.fieldsStore).containErrors.apply(_a, __spread(fieldNames));
        var _a;
    };
    FormWithConstraints.prototype.render = function () {
        var _this = this;
        var _a = this.props, children = _a.children, formProps = __rest(_a, ["children"]);
        return React.createElement("form", __assign({ ref: function (form) { return _this.form = form; } }, formProps), children);
    };
    FormWithConstraints.childContextTypes = {
        form: PropTypes.object.isRequired
    };
    return FormWithConstraints;
}(withValidateEventEmitter(FormWithConstraintsComponent)));

var FieldFeedbacksComponent = (function (_super) {
    __extends(FieldFeedbacksComponent, _super);
    function FieldFeedbacksComponent() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return FieldFeedbacksComponent;
}(React.Component));
var FieldFeedbacks = (function (_super) {
    __extends(FieldFeedbacks, _super);
    function FieldFeedbacks(props, context) {
        var _this = _super.call(this, props) || this;
        _this.fieldFeedbackKey = 0;
        _this.validate = _this.validate.bind(_this);
        _this.reRender = _this.reRender.bind(_this);
        _this.key = context.form.computeFieldFeedbacksKey();
        return _this;
    }
    FieldFeedbacks.prototype.getChildContext = function () {
        return {
            fieldFeedbacks: this
        };
    };
    FieldFeedbacks.prototype.computeFieldFeedbackKey = function () {
        return this.key + this.fieldFeedbackKey++ / 10;
    };
    FieldFeedbacks.prototype.componentWillMount = function () {
        var fieldName = this.props.for;
        this.context.form.fieldsStore.addField(fieldName);
        this.context.form.addValidateEventListener(this.validate);
        this.context.form.fieldsStore.addListener(exports.FieldEvent.Updated, this.reRender);
    };
    FieldFeedbacks.prototype.componentWillUnmount = function () {
        var fieldName = this.props.for;
        this.context.form.fieldsStore.removeField(fieldName);
        this.context.form.removeValidateEventListener(this.validate);
        this.context.form.fieldsStore.removeListener(exports.FieldEvent.Updated, this.reRender);
    };
    FieldFeedbacks.prototype.validate = function (input) {
        var fieldName = this.props.for;
        if (input.name === fieldName) {
            this.context.form.fieldsStore.removeFieldFor(fieldName, this.key);
            this.emitValidateEvent(input);
        }
    };
    FieldFeedbacks.prototype.reRender = function (_fieldName) {
        var fieldName = this.props.for;
        if (fieldName === _fieldName) {
            this.forceUpdate();
        }
    };
    FieldFeedbacks.prototype.render = function () {
        var _a = this.props, fieldName = _a.for, show = _a.show, children = _a.children, divProps = __rest(_a, ["for", "show", "children"]);
        return React.createElement("div", __assign({}, divProps), children);
    };
    FieldFeedbacks.defaultProps = {
        show: 'first'
    };
    FieldFeedbacks.contextTypes = {
        form: PropTypes.object.isRequired
    };
    FieldFeedbacks.childContextTypes = {
        fieldFeedbacks: PropTypes.object.isRequired
    };
    return FieldFeedbacks;
}(withValidateEventEmitter(FieldFeedbacksComponent)));

var FieldFeedback = (function (_super) {
    __extends(FieldFeedback, _super);
    function FieldFeedback(props, context) {
        var _this = _super.call(this, props) || this;
        _this.validate = _this.validate.bind(_this);
        _this.key = context.fieldFeedbacks.computeFieldFeedbackKey();
        return _this;
    }
    FieldFeedback.prototype.componentWillMount = function () {
        this.context.fieldFeedbacks.addValidateEventListener(this.validate);
    };
    FieldFeedback.prototype.componentWillUnmount = function () {
        this.context.fieldFeedbacks.removeValidateEventListener(this.validate);
    };
    FieldFeedback.prototype.validate = function (input) {
        var _a = this.props, when = _a.when, warning = _a.warning, info = _a.info;
        var fieldName = this.context.fieldFeedbacks.props.for;
        var show = false;
        if (typeof when === 'function') {
            var constraintViolation = when(input.value);
            if (constraintViolation) {
                show = true;
            }
        }
        else if (typeof when === 'string') {
            var validity = input.validity;
            if (!validity.valid) {
                if (when === '*') {
                    show = true;
                }
                else if (validity.badInput && when === 'badInput' ||
                    validity.patternMismatch && when === 'patternMismatch' ||
                    validity.rangeOverflow && when === 'rangeOverflow' ||
                    validity.rangeUnderflow && when === 'rangeUnderflow' ||
                    validity.stepMismatch && when === 'stepMismatch' ||
                    validity.tooLong && when === 'tooLong' ||
                    validity.tooShort && when === 'tooShort' ||
                    validity.typeMismatch && when === 'typeMismatch' ||
                    validity.valueMissing && when === 'valueMissing') {
                    show = true;
                }
            }
        }
        else {
            throw new TypeError("Invalid FieldFeedback 'when' type: " + typeof when);
        }
        var field = this.context.form.fieldsStore.cloneField(fieldName);
        field.dirty = true;
        field.validationMessage = input.validationMessage;
        if (show) {
            if (warning)
                field.warnings.add(this.key);
            else if (info)
                field.infos.add(this.key);
            else
                field.errors.add(this.key);
        }
        this.context.form.fieldsStore.updateField(fieldName, field);
    };
    FieldFeedback.prototype.className = function () {
        var _a = this.context.fieldFeedbacks.props, fieldName = _a.for, show = _a.show;
        var _b = this.context.form.fieldsStore.getFieldFor(fieldName, this.context.fieldFeedbacks.key), errors = _b.errors, warnings = _b.warnings, infos = _b.infos;
        var firstError = errors.values().next().value;
        var firstWarning = warnings.values().next().value;
        var className;
        if (errors.has(this.key) && (show === 'all' || (show === 'first' && firstError === this.key))) {
            className = 'error';
        }
        else if (warnings.has(this.key) && (errors.size === 0 && (show === 'all' || (show === 'first' && firstWarning === this.key)))) {
            className = 'warning';
        }
        else if (infos.has(this.key)) {
            className = 'info';
        }
        return className;
    };
    FieldFeedback.prototype.render = function () {
        var _a = this.props, when = _a.when, error = _a.error, warning = _a.warning, info = _a.info, className = _a.className, children = _a.children, divProps = __rest(_a, ["when", "error", "warning", "info", "className", "children"]);
        var fieldName = this.context.fieldFeedbacks.props.for;
        var validationMessage = this.context.form.fieldsStore.getFieldFor(fieldName, this.context.fieldFeedbacks.key).validationMessage;
        var classes = this.className();
        var feedback = null;
        if (classes !== undefined) {
            classes = className !== undefined ? className + " " + classes : classes;
            feedback = children !== undefined ? children : validationMessage;
        }
        return feedback !== null ? React.createElement("div", __assign({}, divProps, { className: classes }), feedback) : null;
    };
    FieldFeedback.contextTypes = {
        form: PropTypes.object.isRequired,
        fieldFeedbacks: PropTypes.object.isRequired
    };
    return FieldFeedback;
}(React.Component));

exports.fieldWithoutFeedback = fieldWithoutFeedback;
exports.FormWithConstraintsComponent = FormWithConstraintsComponent;
exports.FormWithConstraints = FormWithConstraints;
exports.FieldFeedbacksComponent = FieldFeedbacksComponent;
exports.FieldFeedbacks = FieldFeedbacks;
exports.FieldFeedback = FieldFeedback;
exports.FieldsStore = FieldsStore;
exports.EventEmitter = EventEmitter;
exports.ValidateEvent = ValidateEvent;
exports.withValidateEventEmitter = withValidateEventEmitter;

Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=react-form-with-constraints.development.js.map
